---
name: tenant-log-migration
description: Migrate a HRLink log4net XxxService to tenant-aware logging with TenantLog.Wrap. Use when modifying service logger initialization, project references, log4net configuration, tests, or when documenting tenant isolation.
---

# TenantLog Service Migration

Use this skill to migrate one HRLink `XxxService` at a time. The goal is to attach the verified tenant id to log4net events without editing every business log statement.

## Required reference

Read the complete human handoff SOP before editing: `05-TenantLog给其他XxxService改造手术级SOP-202610101141.md`. It records the AccessService source paths, exact line numbers, full patch, test commands, known build blockers, and rollback. Do not infer missing facts from this skill.

## Safety and correctness rules

1. Identify the canonical repository, branch, project, and current source version. Do not edit an extracted snapshot and call it a production-ready repository. Do not deploy unless the user separately authorized deployment.
2. Trace service lifetime and the tenant source first. Constructor-bound `TenantLog.Wrap(inner, TenantID)` is safe only for per-call/per-request or strictly tenant-scoped service instances. Never bind tenant to a singleton, static logger, shared service, or controller constructed before tenant resolution. If lifetime is shared, stop and design a request-scoped TenantContext/enricher.
3. Only trust the tenant id after authentication/tenant resolution. Missing tenant must not inherit a previous request. The wrapper maps blank tenant to `unknown`.
4. Keep the existing logger name, repository, level, appenders, log message, and exception behavior. Wrap the existing `ILog`; do not create per-tenant logger names or rewrite every log call.
5. Ensure Service and Host resolve the same Infrastructure assembly containing `TenantLog`; remove/upgrade stale references without adding duplicate assembly sources. Ensure the host actually loads the log4net config containing `%property{tenantid}`. Check publish/plugin overlays for an old DLL overwrite.
6. Search for bypasses: static `ILog`, `wrapped.Logger`, direct `ILogger.Log`, `GlobalContext`, `Console.WriteLine`, custom LogHelper. State which are outside the migration.
7. Add meaningful tests for tenant A/B concurrency, context restore/no leakage, exception/format preservation, caller location, and a real service integration test. Unit tests do not prove Host build or production log ingestion.
8. Document each source file with project-relative path, exact line numbers, before/after snippet, reason, test result, blockers, and rollback. Do not claim a test passed if not run.

## Migration outline

1. Inspect constructor, controller/action creation or DI lifetime, request tenant validation, and all logger creation/use sites. Record line-level evidence.
2. Verify the shared implementation exists at `9.构件/util/Common/HRLink.Framework.Infrastructure/Common/logging/TenantLog.cs` and inspect its API. Do not fork a copy into the service project.
3. Replace only the existing logger initialization, preserving its original `GetLogger` overload:

   ```csharp
   var inner = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
   this.Logger = HRLink.Framework.Infrastructure.TenantLog.Wrap(inner, TenantID);
   ```

4. Reference the same Infrastructure project/package from Service and Host. Avoid old package + new project reference duplication.
5. Add `%property{tenantid}` to the configuration actually loaded by the Host, and ensure it is copied/mounted to the runtime location.
6. Run wrapper unit tests, service integration tests, and full Host build separately. Verify the final dependency graph/output assembly and test concurrent tenant isolation.
7. Verify a non-side-effect request produces the tenant field in runtime logs and Loki/Alloy. Record evidence and explicit limitations.
8. Give a reversible rollback path. Do not perform production rollout without separate authorization.

## AccessService reference facts

The demonstrated AccessService is constructed in action methods (`AccessController.cs:65` in Login; 151 service construction call sites in that Controller), not held as a static/shared service. `AccessService.cs:39` accepts tenant and calls `base(TenantID)`; wrapper initialization is at lines 45–46. The Host project excludes test sources at `HRLink.BackendService.OpenApi.csproj:25`, references shared Infrastructure at line 93, and copies `log4net.config` at lines 113–115. Both Access and Host patterns add tenant property at `log4net.config:21`. See the SOP and complete patch for exact original/current diffs.

## Change history

| Version | Time (Asia/Shanghai) | Summary |
|---|---|---|
| v1.0 | 2026-10-10 12:17:22 +08:00 | Created agent-executable tenant-aware log4net migration workflow based on AccessService source evidence. |
