<!-- change-history:top:start -->
## 变更历史（顶部）

| 版本 | 变更时间（北京时间，UTC+08:00） | 变更概述 |
|---|---|---|
| v1.4 | 2026-10-10 12:23:00 +08:00 | 修正 SOP 命令块的 shell 续行符，确保复制后可直接执行。 |
| v1.3 | 2026-10-10 12:21:00 +08:00 | 补上两个 csproj 被删除的旧包引用原始行号（Access 第 87 行、Host 第 92 行），并明确其改后引用位置。 |
| v1.2 | 2026-10-10 12:17:22 +08:00 | 将原概览SOP升级为可交接执行手册：逐文件精确到源码行、前后代码、项目引用、实例生命周期证据、执行步骤、测试和回滚，并链接完整补丁及Agent Skill。 |
| v1.1 | 2026-10-10 11:42:59 +08:00 | 补正灰度 DLL 作为临时引用和源码/API模型版本对齐的验收步骤。 |
| v1.0 | 2026-10-10 11:41:19 +08:00 | 记录从 AccessService 向其他 XxxService 迁移 TenantLog 的逐步改造、测试和验收方法。 |
<!-- change-history:top:end -->


作者：Gaugectl Richter

记录时间：2026-10-10 12:17:22 +08:00

# 目的与交付对象

这份手册让没有参与本次开发的 HRLink 后端开发人员和 coding agent，可以从 AccessService 样例独立完成其他 `XxxService` 的租户日志改造。它不是“把 GetLogger 外面包一下”这种摘要，而是本次实际源码变更的逐文件记录与迁移操作步骤。执行时先读本手册，再应用同目录的 `TenantLog-AccessService完整源码补丁.patch`；Skill 版执行规则位于 `agent-skill/tenant-log-migration/SKILL.md`。

**源码快照根目录**：`/root/agentic-engineer/graph-lab/cursor-on-硅谷/master遗留工程`。其内容从 `master-code.zip` 解压而来，不是正式 Git 工作树。本次没有提交或推送，也没有改 ACK。完整原始补丁只含本次 9 个新增/修改文件，不包含 `.ops-private` 中的 DLL 或凭据。

本次源码改动主旨：在共享 Common Infrastructure 中新增 log4net `ILog` 代理；AccessService 构造时用该类绑定本次服务实例的 `TenantID`；只在每条实际日志调用的短作用域内写入 `LogicalThreadContext.Properties["tenantid"]` 并在结束时恢复；配置 pattern 输出该字段；宿主和 AccessService 都引用同一份 Infrastructure 源码；增加行为测试。

# 先理解实例生命周期：为什么这里按实例绑定 tenant

证据文件：`9.服务/HR/AccessService/HRLink.BackendService.AccessService/Controllers/AccessController.cs`。

- Controller 构造函数在第 32–38 行，只初始化 Controller 自己的普通 logger；第 34 行的 AccessService 创建是注释，不是实际实例。
- `Login` action 在第 45–46 行声明，在第 65 行执行 `new HRLink.BackendService.Service.AccessService(request.TenantID)`，第 66 行随即调用该实例。
- 同一 Controller 源码内统计到 **151 个** `new AccessService(...)` 调用点，都是 action 方法中的局部变量创建；不是 Controller 单例持有的静态 AccessService。
- `AccessService` 构造函数在 `Service/AccessService.cs:39–48`，基类通过 `base(TenantID)` 接收 tenant，再于第 45–46 行创建 tenant-bound logger。因此本例绑定值是这次构造调用的 tenant。

所以本次的 `Wrap(inner, TenantID)` 仅适用于**每次请求/每个 tenant scope 创建实例**的 service。不要把这段照搬到 singleton、static service、跨请求缓存实例，或构造时没有 tenant 的对象：那会把第一个租户固定在 logger 上。遇到这类类型，需先设计 request-scoped `TenantContext`/日志 enricher，并从已认证的请求上下文逐条读取，不能继续使用构造时绑定方案。

此外，Controller 自己的 logger 位于构造函数第 37 行，没有 tenant 信息；本次并未改 Controller logger，也不声称覆盖 Controller 的日志。

# 本次源码改动逐文件手术记录

以下路径均以源码快照根目录为起点；行号是交付版实际行号，行号可用 `nl -ba <文件>`复核。可直接应用的完整逐字差异见 ZIP 内补丁。没有列出的文件没有纳入本次修改。

## 1. 新增公共实现 TenantLog.cs

项目目录：`9.构件/util/Common/HRLink.Framework.Infrastructure/`  
文件：`Common/logging/TenantLog.cs`（新增 156 行）

关键行及作用：

| 行 | 内容/作用 |
|---|---|
| 1–7 | 引用 `DispatchProxy`、log4net API、repository 与 `SystemStringFormat`。 |
| 9–15 | 放在 `HRLink.Framework.Infrastructure` 命名空间，公开静态 `TenantLog`。 |
| 17 | 固定 log4net 属性名为小写 `tenantid`，需与 PatternLayout、Alloy 标签解析一致。 |
| 22–29 | `Wrap(ILog inner, string tenantId)` 校验 null，创建 `ILog` 动态代理并初始化。 |
| 31–36 | 提供按 repository/loggerName 包装的重载，仍复用原 logger。 |
| 38–49 | 代理保存内层 logger 和构造时 tenant；空白值归一为 `unknown`，避免继承上次请求的 tenant。 |
| 51–84 | 所有 `ILog` 方法进入统一转发；识别五级常规日志与格式化日志，保留 Exception 对象。非日志接口成员转发到原 `ILog`。 |
| 61–71 | 检查原 logger 级别；设置 tenant 的作用域后调用 `ILogger.Log`；caller stack boundary 设为生成代理类型，避免日志位置落在 proxy/reflection。 |
| 86–93 | 写入 `LogicalThreadContext.Properties["tenantid"]` 并保存先前值。它是在每次写日志时执行，不在实例构造时持有线程上下文。 |
| 95–129 | 将 Debug/Info/Warn/Error/Fatal 及 `Format` 变体映射为 log4net Level，并恢复 `SystemStringFormat` 行为。 |
| 132–153 | `IDisposable` 恢复此前属性；之前没有值时移除 tenant 属性，防止作用域泄漏。 |

设计边界：`ILog.Logger`（代理 `Invoke` 第 56–57 行）返回底层 logger，供 log4net 接口语义使用；如果业务代码自己访问 `wrapped.Logger.Log(...)`，将绕过包装器。迁移后应检索 `.Logger.` 旁路调用。

## 2. 修改 AccessService 唯一 logger 初始化点

项目目录：`9.服务/HR/AccessService/HRLink.BackendService.AccessService/`  
文件：`Service/AccessService.cs` 第 39–48 行，实际变化在 45–46 行。

改前：

```csharp
this.Logger = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
```

改后（45–46 行）：

```csharp
this.Logger = HRLink.Framework.Infrastructure.TenantLog.Wrap(
    log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType), TenantID);
```

第 39 行的 `AccessService(string TenantID) : base(TenantID)` 没有更改。原有 `Logger.Info/Error/...` 业务调用没有逐条改写；改动只发生在 logger 对象创建位置。

## 3. 修改 AccessService 项目引用

文件：`9.服务/HR/AccessService/HRLink.BackendService.AccessService/HRLink.BackendService.AccessService.csproj`。

原始源码第 87 行删除旧的 Infrastructure 版本化 `PackageReference`（`HRLink.Framework.Infrastructure` 6.0.2.4），改后在第 98–100 行新增：

```xml
<ItemGroup>
  <ProjectReference Include="..\..\..\..\9.构件\util\Common\HRLink.Framework.Infrastructure\HRLink.Framework.Infrastructure.csproj" />
</ItemGroup>
```

交付版实际引用行是 99。这样 `AccessService` 编译时能看到刚添加的 `TenantLog.Wrap`。不能让项目同时解析到“含新 API 的源代码”和“旧 NuGet Infrastructure DLL”。

## 4. 修改 Backend OpenApi 宿主项目

文件：`9.构件/FBL/B6.mvc/hr/HRLink.BackendService.OpenApi/HRLink.BackendService.OpenApi.csproj`。

- 第 25 行增加 `<Compile Remove="TenantLog.IntegrationTests\**" />`。Host 项目使用默认递归编译；若不排除测试目录，会把 xUnit 测试源码混进宿主编译。
- 原始源码第 92 行的 Infrastructure NuGet `PackageReference` 被删除；交付版第 93 行替换为同一个 Common Infrastructure `ProjectReference`。Access 与 Host 必须从同一个项目构建，避免运行时加载没有 `TenantLog` 方法的旧 DLL。
- 第 113–115 行增加 `log4net.config` 的 `CopyToOutputDirectory=PreserveNewest`，确保宿主发布目录带上修改后的实际日志配置。

## 5. 修改两个 log4net 配置

文件 A：`9.服务/HR/AccessService/HRLink.BackendService.AccessService/log4net.config` 第 21 行。  
文件 B：`9.构件/FBL/B6.mvc/hr/HRLink.BackendService.OpenApi/log4net.config` 第 21 行。

两处 PatternLayout 都新增：

```xml
租户：%property{tenantid}
```

其余时间、线程、级别、日志消息字段保持原 pattern 结构。必须确认**宿主真实加载的配置文件**已被复制/挂载到输出目录；仅修改 AccessService 子项目目录中的 XML，不保证宿主运行时会读取该文件。

## 6. 新增测试项目和测试

项目目录：`9.构件/FBL/B6.mvc/hr/HRLink.BackendService.OpenApi/TenantLog.IntegrationTests/`。

- `HRLink.BackendService.OpenApi.TenantLog.IntegrationTests.csproj:1–24`：net6.0 xUnit 项目。默认只引用公共 Infrastructure；第 17–20 行通过 `EnableAccessServiceIntegrationTests=true` 才编入 Host 与 AccessService 项目引用，避免普通公共行为测试因大型遗留工程私有依赖而无法 restore。
- `TenantLogTests.cs:10–91`：4 个 xUnit 用例：保留 logger name、异常对象、调用位置和格式化结果；并发 func/demo 隔离和上下文恢复；缺 tenant 写 `unknown` 且不泄漏；null logger 抛 `ArgumentNullException`。
- `AccessServiceTenantLogTests.cs:1–28`：条件编译的真实 AccessService 集成用例，构造 `AccessService("tenant-test")` 并检查事件 tenant。当前全量 Access 项目仍有依赖/源码模型错配错误，所以该用例只写入，没有声称已运行通过。

# 其他 XxxService 的可执行迁移步骤

在每个 service 项目单独执行以下步骤。一次只迁移一个 service；记录旧/新文件、行号、构建版本和测试输出，再做下一个，避免把不同生命周期类型当成同一种。

1. **确定真实源码项目。** 在正式源仓中找唯一 `XxxService.csproj`，确认它依赖哪个 Host、哪个 `HRLink.Framework.Infrastructure`。不要从 `master-code.zip`、旧灰度镜像反编译物或同名实验目录构建发布。若目前只能操作快照，先在报告中明确“非 Git 快照，不可直接发布”。
2. **确定实例生命周期。** 从 Controller/action、DI 注册、Host 启动代码跟踪 `new XxxService(tenant)` / `AddScoped` / `AddSingleton`。对实例数与租户边界给出源码行证据。只有 per-call、per-request 或严格 tenant-scoped 实例，才可把构造 tenant 绑定到 logger。发现 singleton/static/共享缓存时停止此 SOP 的绑定方式，改用请求作用域 TenantContext。
3. **确定 tenant 的可信来源。** 找到认证/解析后的 TenantID 参数，以及构造函数是否把它传给基类。不能直接信任未经验证的 query/header/cookie 值；不能用 namespace、镜像 tag、当前线程猜测 tenant。
4. **盘点全部日志出口。** 搜索 `LogManager.GetLogger`、静态 `ILog`、`Logger.Logger`、`GlobalContext`、`LogicalThreadContext`、`Console.WriteLine`、自定义 `LogHelper`、直接 `ILogger.Log`。列出不经过目标 ILog 的旁路。此包装器只涵盖经被包装 `ILog` 写出的日志。
5. **核对公共实现。** 确认该分支的 Infrastructure 确有 `TenantLog.cs`，命名空间/API一致，目标框架引用 log4net 兼容版本。不能复制一份到 service 私有目录，否则以后会形成多个实现。
6. **替换 service 初始化语句。** 保持原 logger name、repository、过滤级别和 appender，只做：

   ```csharp
   var inner = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
   this.Logger = HRLink.Framework.Infrastructure.TenantLog.Wrap(inner, TenantID);
   ```

   若原构造使用别的 `GetLogger` 重载，保留其参数；不要统一改成上面这一种而改变 Logger 名称。
7. **接通项目引用。** 将旧 Infrastructure PackageReference 改成正式源码 ProjectReference，或按组织正式方案升级同版本内部 NuGet 包；Access/Service 与最终 Host 必须解析同一个、包含 `TenantLog` 的 assembly。禁止 ProjectReference 与旧包同时引入重复 DLL。
8. **确保有效 PatternLayout 有字段。** 找出容器进程实际读取的 log4net.config，不是只找最接近 service 的文件；增加 `%property{tenantid}`。检查 Docker 发布输出、ConfigMap/挂载和 Alloy multiline/parser 不会把字段过滤掉。
9. **运行公共测试和 service 测试。** 执行本文下方命令；新增同一 service 的两个租户并发用例、缺租户用例及异常/格式化日志用例。真实集成测试应在该 service 及 Host 均可编译的企业依赖环境运行，不得以公共 wrapper 的单测代替 service integration。
10. **检查依赖和最终输出。** clean build Infrastructure→Service→Host；检查 `project.assets.json`、Host `.deps.json`、发布目录中的 Infrastructure 只有一个预期版本；确保旧 plugin DLL 不会覆盖新 Infrastructure。将有效 log4net.config 和 assembly version/hash 归档。
11. **运行日志验收。** 在允许的非生产验证环境分别触发两个无副作用业务请求；从 appender/Pod 文件/Loki 验证 tenant 字段和值、事件所属服务、时间与调用位置。不得发送客户消息或触发有业务副作用的接口作为日志探针。
12. **回滚。** 可单独回退 logger 初始化语句为原 `GetLogger`、恢复原配置 pattern、恢复上个匹配版本的 Infrastructure 与 Host artifact。不要删除日志数据，不要清理租户上下文的其他属性。生产回滚需走既有发布授权，不由本 SOP 自动执行。

# 本次复现命令与真实验证边界

在源码快照根目录执行公共测试：

```bash
DOTNET_ROLL_FORWARD=Major dotnet test \
  '9.构件/FBL/B6.mvc/hr/HRLink.BackendService.OpenApi/TenantLog.IntegrationTests/HRLink.BackendService.OpenApi.TenantLog.IntegrationTests.csproj' \
  --no-restore -v:q -p:WarningLevel=0
```

已验证结果：**4/4 公共包装器测试通过**。本机只有 .NET 8 runtime，测试目标为 net6.0，因此用了临时的 `DOTNET_ROLL_FORWARD=Major`。

以下命令用于依赖齐全的环境真实编译/集成，不代表本机当前已通过：

```bash
dotnet test \
  '9.构件/FBL/B6.mvc/hr/HRLink.BackendService.OpenApi/TenantLog.IntegrationTests/HRLink.BackendService.OpenApi.TenantLog.IntegrationTests.csproj' \
  -p:EnableAccessServiceIntegrationTests=true
```

真实 AccessService build/integration **未通过**：灰度容器只读复制的 DLL 仅用于本地 restore 临时引用；随后 AccessService 源码全量编译仍报 18 项，包含缺少 Aliyun OSS/ServiceStack/SqlSugar/NBuilder 引用、EMSService namespace/reference 不一致、Api.Model 源码与 ACK DLL 缺少类型等。不能将其描述为 AccessService 已集成成功。ACK 未修改、镜像未发布。

原始源码 patch 由 `master-code.zip` 对上述 9 个文件逐行生成，见同目录 `TenantLog-AccessService完整源码补丁.patch`；它是逐字可审查差异，也是 ZIP 内的审计依据。应用前先确认目标源码版本与补丁前提一致，补丁不能盲目套到另一分支。

# 变更交接检查清单

- [ ] 确认源码仓库、branch、commit 与唯一项目目录。
- [ ] 记录 XxxService 生命周期和 tenant 来源的源码行证据。
- [ ] 搜索出所有 logger 实例和旁路出口。
- [ ] 只在合适的实例 logger 初始化处 Wrap，业务日志调用不逐条修改。
- [ ] Service 与 Host 解析同一 Infrastructure，输出目录无旧 DLL 覆盖。
- [ ] 修改容器实际生效的 log4net.config，核对 Alloy/Loki 字段解析。
- [ ] 公共测试、service 集成、Host build 各自报告，不互相替代。
- [ ] 两租户并发验证、异常验证、真实日志验证均有证据。
- [ ] 修改记录列出每个文件的绝对/相对路径、改前改后、行号、原因和验证结果。
- [ ] 生产变更另行授权，本 SOP 本身不构成 ACK 部署许可。


<!-- change-history:bottom:start -->
## 变更历史（底部）

| 版本 | 变更时间（北京时间，UTC+08:00） | 变更概述 |
|---|---|---|
| v1.4 | 2026-10-10 12:23:00 +08:00 | 修正 SOP 命令块的 shell 续行符，确保复制后可直接执行。 |
| v1.3 | 2026-10-10 12:21:00 +08:00 | 补上两个 csproj 被删除的旧包引用原始行号（Access 第 87 行、Host 第 92 行），并明确其改后引用位置。 |
| v1.2 | 2026-10-10 12:17:22 +08:00 | 将原概览SOP升级为可交接执行手册：逐文件精确到源码行、前后代码、项目引用、实例生命周期证据、执行步骤、测试和回滚，并链接完整补丁及Agent Skill。 |
| v1.1 | 2026-10-10 11:42:59 +08:00 | 补正灰度 DLL 作为临时引用和源码/API模型版本对齐的验收步骤。 |
| v1.0 | 2026-10-10 11:41:19 +08:00 | 记录从 AccessService 向其他 XxxService 迁移 TenantLog 的逐步改造、测试和验收方法。 |
<!-- change-history:bottom:end -->
