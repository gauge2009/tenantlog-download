#if ACCESS_SERVICES_INTEGRATION
using HRLink.BackendService.Service;
using log4net;
using log4net.Appender;
using log4net.Config;
using Xunit;

namespace HRLink.BackendService.OpenApi.TenantLog.IntegrationTests;

public sealed class AccessServiceTenantLogTests
{
    [Fact]
    public void AccessServiceConstructorBindsTenantToItsExistingLogger()
    {
        var repository = LogManager.GetRepository(typeof(AccessService).Assembly);
        var appender = new MemoryAppender();
        BasicConfigurator.Configure(repository, appender);

        var service = new AccessService("tenant-test");
        service.Logger.Info("AccessService tenant binding probe");

        var item = Assert.Single(appender.GetEvents());
        Assert.Equal("HRLink.BackendService.Service.AccessService", item.LoggerName);
        Assert.Equal("tenant-test", item.Properties["tenantid"]);
        Assert.Contains(nameof(AccessService), item.LocationInformation.ClassName);
    }
}
#endif
