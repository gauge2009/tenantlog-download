using HRLink.Framework.Infrastructure;
using log4net;
using log4net.Appender;
using log4net.Config;
using log4net.Repository;
using Xunit;

namespace HRLink.BackendService.OpenApi.TenantLog.IntegrationTests;

public sealed class TenantLogTests
{
    private static (ILoggerRepository Repository, MemoryAppender Appender, ILog Logger) CreateLogger()
    {
        var repository = LogManager.CreateRepository("TenantLogTests-" + Guid.NewGuid().ToString("N"));
        var appender = new MemoryAppender();
        BasicConfigurator.Configure(repository, appender);
        var logger = LogManager.GetLogger(repository.Name, "HRLink.BackendService.Service.AccessService");
        return (repository, appender, logger);
    }

    [Fact]
    public void Wrap_AddsTenantToEvents_AndPreservesLoggerNameAndException()
    {
        var (_, appender, inner) = CreateLogger();
        var wrapped = HRLink.Framework.Infrastructure.TenantLog.Wrap(inner, "func");
        var exception = new InvalidOperationException("synthetic test failure");

        wrapped.Error("access test", exception);
        wrapped.InfoFormat("formatted {0}", "message");

        var item = Assert.Single(appender.GetEvents().Where(e => e.RenderedMessage == "access test"));
        Assert.Equal("HRLink.BackendService.Service.AccessService", item.LoggerName);
        Assert.Contains("TenantLogTests", item.LocationInformation.ClassName);
        Assert.Equal("func", item.Properties["tenantid"]);
        Assert.Same(exception, item.ExceptionObject);
        Assert.Contains("TenantLogTests", item.LocationInformation.ClassName);
        Assert.Contains(appender.GetEvents(), e => e.RenderedMessage == "formatted message" && Equals(e.Properties["tenantid"], "func"));
    }

    [Fact]
    public async Task Wrap_IsolatesConcurrentTenantCalls_AndRestoresAmbientValue()
    {
        var (_, appender, inner) = CreateLogger();
        var func = HRLink.Framework.Infrastructure.TenantLog.Wrap(inner, "func");
        var demo = HRLink.Framework.Infrastructure.TenantLog.Wrap(inner, "demo");
        using var barrier = new Barrier(2);

        await Task.WhenAll(
            Task.Run(() => { barrier.SignalAndWait(); func.Info("request-func"); }),
            Task.Run(() => { barrier.SignalAndWait(); demo.Info("request-demo"); }));

        var events = appender.GetEvents().ToDictionary(e => e.RenderedMessage);
        Assert.Equal("func", events["request-func"].Properties["tenantid"]);
        Assert.Equal("demo", events["request-demo"].Properties["tenantid"]);

        log4net.LogicalThreadContext.Properties["tenantid"] = "outer-scope";
        try
        {
            func.Info("wrapped-call");
            inner.Info("after-wrapper");
        }
        finally
        {
            log4net.LogicalThreadContext.Properties.Remove("tenantid");
        }

        events = appender.GetEvents().ToDictionary(e => e.RenderedMessage);
        Assert.Equal("func", events["wrapped-call"].Properties["tenantid"]);
        Assert.Equal("outer-scope", events["after-wrapper"].Properties["tenantid"]);
    }

    [Fact]
    public void Wrap_UsesUnknownForMissingTenant_AndDoesNotLeakIt()
    {
        var (_, appender, inner) = CreateLogger();
        var wrapped = HRLink.Framework.Infrastructure.TenantLog.Wrap(inner, " ");

        wrapped.Info("missing-tenant");
        inner.Info("outside-scope");

        var events = appender.GetEvents().ToDictionary(e => e.RenderedMessage);
        Assert.Equal("unknown", events["missing-tenant"].Properties["tenantid"]);
        Assert.False(events["outside-scope"].Properties.Contains("tenantid"));
    }

    [Fact]
    public void Wrap_RejectsNullLogger()
    {
        Assert.Throws<ArgumentNullException>(() => HRLink.Framework.Infrastructure.TenantLog.Wrap((ILog)null!, "func"));
    }
}
