using System;
using System.Reflection;
using System.Runtime.ExceptionServices;
using log4net;
using log4net.Core;
using log4net.Repository;
using log4net.Util;

namespace HRLink.Framework.Infrastructure
{
    /// <summary>
    /// Adds a tenant property to log4net events written through a tenant-bound ILog.
    /// The wrapped logger keeps its original name, repository, level and appenders.
    /// </summary>
    public static class TenantLog
    {
        private const string TenantPropertyName = "tenantid";

        /// <summary>
        /// Wraps an existing logger. Missing tenant identifiers are written as "unknown".
        /// </summary>
        public static ILog Wrap(ILog inner, string tenantId)
        {
            if (inner == null) throw new ArgumentNullException(nameof(inner));

            var proxy = DispatchProxy.Create<ILog, TenantLogProxy>();
            ((TenantLogProxy)(object)proxy).Initialize(inner, tenantId, proxy.GetType());
            return proxy;
        }

        public static ILog Wrap(ILoggerRepository repository, string loggerName, string tenantId)
        {
            if (repository == null) throw new ArgumentNullException(nameof(repository));
            if (string.IsNullOrWhiteSpace(loggerName)) throw new ArgumentException("Logger name is required.", nameof(loggerName));
            return Wrap(LogManager.GetLogger(repository.Name, loggerName), tenantId);
        }

        public class TenantLogProxy : DispatchProxy
        {
            private ILog _inner;
            private string _tenantId;
            private Type _callerBoundary;

            public void Initialize(ILog inner, string tenantId, Type callerBoundary)
            {
                _inner = inner;
                _callerBoundary = callerBoundary;
                _tenantId = string.IsNullOrWhiteSpace(tenantId) ? "unknown" : tenantId.Trim();
            }

            protected override object Invoke(MethodInfo targetMethod, object[] args)
            {
                if (targetMethod == null) throw new ArgumentNullException(nameof(targetMethod));
                if (_inner == null) throw new InvalidOperationException("TenantLog proxy was not initialized.");

                if (targetMethod.Name == "get_Logger" && targetMethod.GetParameters().Length == 0)
                    return _inner.Logger;

                if (TryGetLevel(targetMethod.Name, out var level, out var isFormat))
                {
                    var logger = _inner.Logger;
                    if (!logger.IsEnabledFor(level)) return null;

                    var message = isFormat ? CreateFormatMessage(args) : args[0];
                    var exception = !isFormat && args.Length > 1 ? args[1] as Exception : null;
                    using (PushTenant())
                    {
                        // Passing the proxy type as the stack boundary preserves the original
                        // business call site in log4net LocationInfo.
                        logger.Log(_callerBoundary ?? typeof(TenantLogProxy), level, message, exception);
                    }
                    return null;
                }

                try
                {
                    return targetMethod.Invoke(_inner, args);
                }
                catch (TargetInvocationException ex) when (ex.InnerException != null)
                {
                    ExceptionDispatchInfo.Capture(ex.InnerException).Throw();
                    throw;
                }
            }

            private IDisposable PushTenant()
            {
                var properties = log4net.LogicalThreadContext.Properties;
                var previous = properties[TenantPropertyName];
                var hadPrevious = previous != null;
                properties[TenantPropertyName] = _tenantId;
                return new RestoreTenantScope(properties, hadPrevious, previous);
            }

            private static bool TryGetLevel(string methodName, out Level level, out bool isFormat)
            {
                isFormat = methodName.EndsWith("Format", StringComparison.Ordinal);
                var name = isFormat ? methodName.Substring(0, methodName.Length - "Format".Length) : methodName;
                switch (name)
                {
                    case "Debug": level = Level.Debug; return true;
                    case "Info": level = Level.Info; return true;
                    case "Warn": level = Level.Warn; return true;
                    case "Error": level = Level.Error; return true;
                    case "Fatal": level = Level.Fatal; return true;
                    default: level = null; return false;
                }
            }

            private static object CreateFormatMessage(object[] args)
            {
                var hasProvider = args.Length > 0 && args[0] is IFormatProvider;
                var provider = hasProvider ? (IFormatProvider)args[0] : null;
                var formatIndex = hasProvider ? 1 : 0;
                var format = (string)args[formatIndex];
                var argumentIndex = formatIndex + 1;
                object[] formatArgs;

                if (argumentIndex == args.Length)
                    formatArgs = Array.Empty<object>();
                else if (argumentIndex == args.Length - 1 && args[argumentIndex] is object[] array)
                    formatArgs = array;
                else
                {
                    formatArgs = new object[args.Length - argumentIndex];
                    Array.Copy(args, argumentIndex, formatArgs, 0, formatArgs.Length);
                }

                return new SystemStringFormat(provider, format, formatArgs);
            }

            private sealed class RestoreTenantScope : IDisposable
            {
                private readonly log4net.Util.LogicalThreadContextProperties _properties;
                private readonly bool _hadPrevious;
                private readonly object _previous;
                private bool _disposed;

                public RestoreTenantScope(log4net.Util.LogicalThreadContextProperties properties, bool hadPrevious, object previous)
                {
                    _properties = properties;
                    _hadPrevious = hadPrevious;
                    _previous = previous;
                }

                public void Dispose()
                {
                    if (_disposed) return;
                    _disposed = true;
                    if (_hadPrevious) _properties[TenantPropertyName] = _previous;
                    else _properties.Remove(TenantPropertyName);
                }
            }
        }
    }
}
