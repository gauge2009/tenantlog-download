﻿
using HRLink.BackendService.Api.Model.AccessControllerModel;
using HRLink.BackendService.Repository;
using HRLink.BackendService.Service.Model;
using HRLink.Framework.Cache.Interface;
using HRLink.BackendService.Core;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Newtonsoft.Json;
using HRLink.Framework.ORM;
using HRLink.BackendService.IService;
using HRLink.BackendService.Service;
using HRLink.Framework.ORM.Model;
using JR.Pattern.RepoMaster;
using HRLink.Framework.Cache;
using System.Reflection;
using static HRLink.Framework.ORM.ORMHelper;
using HRLink.BackendService.Api.Model.EmployeeControllerModel;
using System.Text.RegularExpressions;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]
namespace HRLink.BackendService.Service
{
    public partial class AccessService : BaseRepository, IAccessService
    {
        Regex ConstReg = new Regex(@"(?<=<%const=)(\w+)(?=%>)+");
        //public CacheService IService { get; set; }
        //public ConfigurationService ConfService { get; set; }
        //public MsgQService MsgQService { get; set; }
        //public FileService FileService { get; set; }
        public log4net.ILog Logger
        {
            get;
            set;
        }
        public Framework.Infrastructure.LogHelper logHelper { get; set; }
        public AccessService(string TenantID) : base(TenantID)
        {
            //IService = new CacheService(TenantID);//后期优化
            //ConfService = new ConfigurationService(TenantID);
            //MsgQService = new MsgQService(TenantID);
            //FileService = new FileService(TenantID);
            this.Logger = HRLink.Framework.Infrastructure.TenantLog.Wrap(
                log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType), TenantID);
            logHelper = new Framework.Infrastructure.LogHelper();
        }

        internal class ViewEmp
        {
            public string emp_id { get; set; }
        }

        public string PasswordEncrypt(string Password)
        {
            string PasswordEncryptMode = "3des";
            var config = new ConfigurationService(TenantID).GetConfig(new List<string> { "PasswordEncryptMode" }, "all");
            if (config.Count > 0 && !string.IsNullOrWhiteSpace(config.First().ConfigValue))
            {
                PasswordEncryptMode = config.First().ConfigValue;
            }
            switch (PasswordEncryptMode.ToLower())
            {
                case "sm3":
                    return HRLink.BackendService.Core.SM3Helper.Hash(Password);
                case "sm4":
                    return HRLink.BackendService.Core.SM4Helper.Encrypt(Password);
                default://3des
                    return HRLink.BackendService.Core.DESHelper.Encrypt3DES(Password);
            }
        }

        public List<string> GetEmpAllPositonList(string EmpID, string SiteCode)
        {
            ORMHelper.ConnectionInfo ConnSite = null;
            ORMHelper.ConnectionInfo ConnSaas = null;
            List<string> PositionList = new List<string>();
            try
            {
                ConnSaas = OpenConnection(ConnType.Saas);
                var siteInfo = ORMHelper.Get<SiteSettingPO>(ConnSaas, SiteCode);
                if (siteInfo != null)
                {
                    var ParttimeSettingPO = new ParttimeSettingPO();
                    ConnSite = OpenConnection(ConnType.Site, SiteCode);
                    ParttimeSettingPO.Where(T => T.Emp_id == EmpID && T.Site_code == SiteCode);
                    var ParttimeSettingPOList = ORMHelper.GetList<ParttimeSettingPO>(ConnSaas, ParttimeSettingPO);
                    foreach (var item in ParttimeSettingPOList)
                    {
                        PositionList.Add(item.Position_relation_id);
                    }


                    var NowDate = DateTime.Now.Date;

                    var EmpPositionTrxPOList = ORMHelper.GetList<EmpPositionTrxPO>(ConnSite, " where emp_id='" + EmpID.Replace("'", "''") + "' and Is_preset=0 and start_date<='" + NowDate.ToString("yyyy-MM-dd") + "' and (end_date is null or end_date>='" + NowDate.ToString("yyyy-MM-dd") + "')");
                    foreach (var item in EmpPositionTrxPOList)
                    {
                        PositionList.Add(item.Position_relation_id);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (ConnSite != null) ConnSite.CloseConn();
                if (ConnSaas != null) ConnSaas.CloseConn();
            }
            return PositionList;

        }

        public enum ModuleType
        {

            HR,
            PAYROLL,
            ATS
        }

        public class OrgInfoScope
        {
            /// <summary>
            /// 
            /// </summary>
            public string OrgID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string OrgName1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string OrgName2 { get; set; }
        }


        /// <summary>
        /// 判断公司使用集团还是公司配置
        /// 返回值  group 、company1 、company2 
        /// </summary>
        /// <param name="siteCode">eg:company1</param>
        /// <param name="type">eg:viewdefine</param>
        /// <param name="connSaas"></param>
        /// <returns></returns>
        public string getGroupCompanySetting(string siteCode, string type, ORMHelper.ConnectionInfo connSaas)
        {
            List<string> keyList = new List<string> {
                    "is_use_group_ats_system",
                    "is_use_group_class_type",
                    "is_use_group_empwidget_setting",
                    "is_use_group_hrwidget_setting",
                    "is_use_group_leavetype_setting",
                    "is_use_group_ottype_setting",
                    "is_use_group_shift_type",
                    "is_use_group_viewdefine_setting",
                    "is_use_group_email_setting",
                    "is_use_group_basicsetup_setting",
                    "is_use_group_attrmanage_setting"
            };
            string result = "group", keyCode = string.Empty;
            bool IsUseGroupSetting = true;
            try
            {
                this.Logger.Info($"++++++++++ GetPage getGroupCompanySetting TenantID ==> {TenantID}");
                var cfgList = new ConfigurationService(TenantID).GetConfig(keyList, "all");
                if (!string.IsNullOrWhiteSpace(type))
                {
                    switch (type.ToLower())
                    {
                        case "attrmanage":
                            keyCode = "is_use_group_attrmanage_setting";
                            break;

                        case "basicsetup":
                            keyCode = "is_use_group_basicsetup_setting";
                            break;

                        case "email":
                            keyCode = "is_use_group_email_setting";
                            break;

                        case "hrwidget":
                            keyCode = "is_use_group_hrwidget_setting";
                            break;
                        case "empwidget":
                            keyCode = "is_use_group_empwidget_setting";
                            break;

                        case "leavetype":
                            keyCode = "is_use_group_leavetype_setting";
                            break;

                        case "ottype":
                            keyCode = "is_use_group_ottype_setting";
                            break;

                        case "shifttype":
                            keyCode = "is_use_group_shift_type";
                            break;

                        case "classtype":
                            keyCode = "is_use_group_class_type";
                            break;

                        case "atssystem":
                            keyCode = "is_use_group_ats_system";
                            break;

                        default:
                            keyCode = "is_use_group_viewdefine_setting";
                            break;
                    }
                }

                var cfgInfo = cfgList.FirstOrDefault(p => p.ConfigKey == keyCode);
                if (cfgInfo != null && !string.IsNullOrWhiteSpace(cfgInfo.ConfigValue) && (cfgInfo.ConfigValue.ToLower() == "true" || cfgInfo.ConfigValue.ToLower() == "1"))
                {
                    IsUseGroupSetting = false;
                }
                // 使用公司配置
                if (!IsUseGroupSetting)
                {
                    if (ORMHelper.GetCount<GroupCompanyOverloadPO>(connSaas, $"where type='{ConvertDBValue(type)}' AND site_code='{ConvertDBValue(siteCode)}'") > 0)
                        result = siteCode;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        public IEnumerable<DictEntityLogicMappingPO> GetAllDicMapping(List<string> fieldIdList)
        {
            ORMHelper.ConnectionInfo connection = null;
            IEnumerable<DictEntityLogicMappingPO> list = null;
            try
            {
                connection = OpenConnection(ConnType.Saas);
                DictEntityLogicMappingPO dicPo = new DictEntityLogicMappingPO();
                string[] Arr = fieldIdList.ToArray();
                dicPo.Where(l => l.Is_enable == true && l.Logic_field_id.In(Arr));

                list = ORMHelper.GetList<DictEntityLogicMappingPO>(connection, dicPo);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.CloseConn();
            }

            return list;
        }

        private string GetValue(Object obj, string name)
        {
            if (null == obj)
            {
                return null;
            }

            var targetType = obj.GetType();
            var propertyInfo = targetType.GetProperty(name);

            if (null == propertyInfo)
            {
                return null;
            }

            Object returnValue = propertyInfo.GetValue(obj);

            if (null == returnValue)
            {
                return null;
            }

            return returnValue.ToString();
        }

        public class ADVModel
        {
            public List<Field> FieldFilter { get; set; }
            public class Field
            {
                //
                // 摘要:
                //     逻辑字段 Key
                public string FieldKey { get; set; }
                //
                // 摘要:
                //     查询控件类型
                public string Type { get; set; }
                //
                // 摘要:
                //     值
                public string Value { get; set; }
            }

            public List<AdvOrgInfo> OrgList { get; set; }
            //
            // 摘要:
            //     组织结构范围解析model
            public class AdvOrgInfo
            {
                //
                // 摘要:
                //     是否全选
                public bool IsAllChecked { get; set; }
                //
                // 摘要:
                //     组织结构ID
                public string OrgRelID { get; set; }

                public List<AdvOrgInfo> OrgList { get; set; }
            }

        }
        public  string GetAdvSearchConditionByFields(ADVModel advance, List<CustomAttrSetPO> GetCusAttrSet, List<OrgRelationPO> orgData, ORMHelper.ConnectionInfo connSaas, ORMHelper.ConnectionInfo conSite)
        {
            string conditionWhere = string.Empty;
            try
            {
                if (advance != null)
                {
                    #region  字段
                    if (advance.FieldFilter != null && advance.FieldFilter.Count > 0)
                    {
                        List<string> fieldIdList = new List<string>();
                        foreach (var adv in advance.FieldFilter) fieldIdList.Add(adv.FieldKey);

                        var dicMapping = ORMHelper.GetList<DictEntityLogicMappingPO>(connSaas, " where logic_field_id in ('" + string.Join("','", fieldIdList.ToArray()) + "')  ");
                        string physicalFieldKey = string.Empty;

                        foreach (var entry in advance.FieldFilter)
                        {
                            var dicPhysicalMapping = dicMapping.Where(p => p.Logic_field_id == entry.FieldKey);
                            string sqlWhere = string.Empty;
                            switch (entry.Type.ToLower())
                            {
                                case "emp-paraselect-effective":
                                    {
                                        if (!string.IsNullOrWhiteSpace(entry.Value))
                                        {
                                            var textDataList = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchPayPlan>(entry.Value);

                                            var paraselect = dicPhysicalMapping.Where(p => p.Logic_field_key == "Value");
                                            sqlWhere += "  emp_id in (select emp_id from " + paraselect.First().Physical_table_name + " where  " + paraselect.First().Physical_field_key + " in ('" + string.Join("','", textDataList.Type.ToArray()) + "'))";
                                        }
                                        break;
                                    }
                                case "search-position":
                                    {
                                        if (!string.IsNullOrWhiteSpace(entry.Value))
                                        {

                                            var TestBoxModel = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchPosition>(entry.Value);

                                            string Where = string.Empty;
                                            string sqlWhere2 = string.Empty;
                                            if (TestBoxModel.SearchText != null)
                                            {
                                                Where = " and (position_name_cn LIKE '%" + TestBoxModel.SearchText + "%'or position_name_en LIKE'%" + TestBoxModel.SearchText + "%' or position_code like '%" + TestBoxModel.SearchText + "%' or position_number like '%" + TestBoxModel.SearchText + "%') ";
                                            }

                                            if (TestBoxModel.customattrlist != null)
                                            {

                                                foreach (var item in TestBoxModel.customattrlist)
                                                {
                                                    var a = GetCusAttrSet.Find(p => p.Attr_key == item.key);
                                                    if (a != null)
                                                    {
                                                        switch (a.Attr_type)
                                                        {
                                                            case "core-bool":
                                                                {
                                                                    sqlWhere2 = "and " + item.key + " = " + item.value + "";
                                                                    break;
                                                                }
                                                            case "core-selectbox":
                                                                {
                                                                    var model = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchSelect>(item.value);
                                                                    sqlWhere2 = "and " + item.key + " = '" + model.DisplayText + "'";
                                                                    break;
                                                                }
                                                            case "core-number":
                                                                {
                                                                    sqlWhere2 = "and " + item.key + " = " + item.value + "";
                                                                    break;
                                                                }
                                                            case "core-dateperiods":
                                                                {
                                                                    var model = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchDate>(item.value);
                                                                    sqlWhere2 = "and " + item.key + " > '" + model.StartValue + "' and " + item.key + " < '" + model.EndValue + "'";
                                                                    break;
                                                                }
                                                            case "core-textarea":
                                                                {
                                                                    sqlWhere2 = "and " + item.key + " = " + item.value + "";
                                                                    break;
                                                                }

                                                        }
                                                    }
                                                }
                                            }

                                            if (Where != null || sqlWhere2 != null)
                                            {
                                                sqlWhere = " emp_id in (select emp_id from v_api_access_empinfo_position where 1=1 " + Where + " " + sqlWhere2 + ")";
                                            }


                                        }
                                        break;
                                    }
                                case "emp-textbox":
                                    {
                                        if (!string.IsNullOrWhiteSpace(entry.Value))
                                        {
                                            var textDataList = JsonConvert.DeserializeObject<List<AdvSearchConditionControl.SeachTextbox>>(entry.Value);

                                            var textData1List = textDataList.FindAll(r => r.Type == "=");
                                            string data1sql = string.Empty;
                                            foreach (var data in textData1List)
                                            {
                                                data1sql += " '" + data.Value + "',";
                                            }

                                            var textData2List = textDataList.FindAll(r => r.Type == "like");
                                            string data2sql = string.Empty;
                                            if (!string.IsNullOrWhiteSpace(data1sql))
                                            {
                                                data2sql = " or ";
                                            }
                                            foreach (var data in textData2List)
                                            {
                                                data2sql += " " + dicPhysicalMapping.First().Physical_field_key + "  like  '%" + data.Value + "%'  or  ";
                                            }
                                            if ((textData1List == null || textData1List.Count == 0) && (textData2List == null || textData2List.Count == 0))
                                            {
                                                continue;
                                            }

                                            if (string.IsNullOrWhiteSpace(data1sql) && !string.IsNullOrWhiteSpace(data2sql))
                                            {
                                                sqlWhere += "  and (  " + data2sql.Substring(0, data2sql.LastIndexOf("or")) + "  )   ";
                                            }
                                            else
                                            {
                                                sqlWhere += "  emp_id in (select emp_id from " + dicPhysicalMapping.First().Physical_table_name + " where " + dicPhysicalMapping.First().Physical_field_key + " in (" + data1sql.TrimEnd(',') + ") " + (string.IsNullOrWhiteSpace(data2sql) == true ? "" : data2sql.Substring(0, data2sql.LastIndexOf("or"))) + "  )   ";
                                            }


                                            //sqlWhere = "and emp_id in (select emp_id from " + dicPhysicalMapping.First().Physical_table_name + " where " + dicPhysicalMapping.First().Physical_field_key + " like '%" + TestBoxModel.Value + "%')";

                                        }
                                        break;
                                    }
                                case "search-annualplan":
                                    {
                                        if (!string.IsNullOrWhiteSpace(entry.Value))
                                        {
                                            var AnnualPlanModel = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchPayPlan>(entry.Value);

                                            sqlWhere = " emp_id in (select emp_id from emp_setting_value where annualleave_plan in ('" + string.Join("','", AnnualPlanModel.Type.ToArray()) + "'))";

                                        }
                                        break;
                                    }
                                case "search-payplan":
                                    {
                                        if (!string.IsNullOrWhiteSpace(entry.Value))
                                        {
                                            var PayPlanModel = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchPayPlan>(entry.Value);

                                            sqlWhere = " emp_id in (select employee_key from emp_payroll_relation where plan_id in ('" + string.Join("','", PayPlanModel.Type.ToArray()) + "') )";

                                        }
                                        break;
                                    }
                                case "search-nuevosemp":
                                    {
                                        if (!string.IsNullOrWhiteSpace(entry.Value))
                                        {
                                            DateTime now = DateTime.Now;
                                            DateTime d1 = new DateTime(now.Year, now.Month, 1);
                                            DateTime d2 = d1.AddMonths(1).AddDays(-1);
                                            DateTime d3 = d1.AddMonths(+1);
                                            DateTime d4 = d1.AddMonths(+2).AddDays(-1);
                                            //var nuevosModel = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchMonth>(entry.Value);
                                            if (entry.Value == "0")
                                            {
                                                sqlWhere = "'" + d1 + "' <= employee_date and '" + d2 + "' > employee_date  ";
                                            }
                                            else
                                            {
                                                sqlWhere = "' " + d3 + "' <= employee_date and '" + d4 + "' > employee_date  ";
                                            }

                                        }
                                        break;
                                    }
                                case "search-probation":
                                    {
                                        if (!string.IsNullOrWhiteSpace(entry.Value))
                                        {
                                            string d1 = DateTime.Now.ToShortDateString().ToString();
                                            //var probationModel = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchMonth>(entry.Value);

                                            sqlWhere = " probation_period_end_date <='" + d1 + "'";

                                        }
                                        break;
                                    }
                                case "search-birthday":
                                    if (!string.IsNullOrWhiteSpace(entry.Value))
                                    {
                                        DateTime now = DateTime.Now;
                                        //var AddMonths = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchMonth>(entry.Value);
                                        int m1 = now.Month + int.Parse(entry.Value);
                                        sqlWhere = " MONTH(date_of_birth)=" + m1 + "";
                                    }
                                    break;
                                case "search-paraselect":
                                    if (!string.IsNullOrWhiteSpace(entry.Value))
                                    {
                                        var paraList = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchParaSelect>(entry.Value);
                                        physicalFieldKey = dicPhysicalMapping.First().Physical_field_key;
                                        if (paraList.type.Count > 0)
                                        {
                                            sqlWhere = "( ";
                                            for (int p_index = 0, p_len = paraList.type.Count; p_index < p_len; p_index++)
                                            {
                                                sqlWhere += physicalFieldKey + "='" + paraList.type[p_index] + "' or ";
                                            }
                                            sqlWhere = sqlWhere.Substring(0, sqlWhere.Length - 3) + " )";
                                        }
                                    }
                                    break;
                                case "search-address":
                                    if (!string.IsNullOrWhiteSpace(entry.Value))
                                    {
                                        var addModel = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchAddress>(entry.Value);

                                        if (!string.IsNullOrWhiteSpace(addModel.provinceCode))
                                        {
                                            sqlWhere = " live_province='" + addModel.provinceCode + "' and ";
                                        }
                                        if (!string.IsNullOrWhiteSpace(addModel.cityCode))
                                        {
                                            sqlWhere = " live_city='" + addModel.cityCode + "' and ";
                                        }

                                        sqlWhere = "( " + sqlWhere.Substring(0, sqlWhere.Length - 4) + " )";
                                    }
                                    break;
                                case "search-identity":
                                    // age20_25 20-25岁 
                                    // age25_30 25-30岁  
                                    // age30_35 30-35岁
                                    // age35_40 35-40岁 
                                    // age40 40岁
                                    if (!string.IsNullOrWhiteSpace(entry.Value))
                                    {
                                        AdvSearchConditionControl.SearchIdentity identityModel = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchIdentity>(entry.Value);
                                        if (!string.IsNullOrWhiteSpace(identityModel.countryCode))
                                        {
                                            sqlWhere = " household_country='" + identityModel.countryCode + "' and";
                                        }
                                        if (!string.IsNullOrWhiteSpace(identityModel.provinceCode))
                                        {
                                            sqlWhere = " household_province='" + identityModel.provinceCode + "' and";
                                        }
                                        if (!string.IsNullOrWhiteSpace(identityModel.cityCode))
                                        {
                                            sqlWhere = " household_city='" + identityModel.cityCode + "' and";
                                        }
                                        if (!string.IsNullOrWhiteSpace(identityModel.nationLabel))
                                        {
                                            sqlWhere = " nation='" + identityModel.nationLabel + "' and";
                                        }
                                        if (!string.IsNullOrWhiteSpace(identityModel.accountType))
                                        {
                                            sqlWhere = " household_type='" + identityModel.accountType + "' and";
                                        }

                                        if (identityModel.ageList != null && identityModel.ageList.Count > 0)
                                        {
                                            string ageWhere = string.Empty;

                                            for (int a_index = 0, a_len = identityModel.ageList.Count; a_index < a_len; a_index++)
                                            {
                                                if (identityModel.ageList[a_index].ToLower() == "age20_25")
                                                {
                                                    //NOW() >= DATE_ADD(date_of_birth,INTERVAL 20 year) and NOW() < DATE_ADD(date_of_birth,INTERVAL 25 year)
                                                    ageWhere += " ('" + DateTime.Now.AddYears(-20) + "' >= date_of_birth and '" + DateTime.Now.AddYears(-25) + "' < date_of_birth )or ";
                                                }
                                                if (identityModel.ageList[a_index].ToLower() == "age25_30")
                                                {
                                                    ageWhere += " ('" + DateTime.Now.AddYears(-25) + "' >= date_of_birth and '" + DateTime.Now.AddYears(-30) + "' < date_of_birth )or ";
                                                }
                                                if (identityModel.ageList[a_index].ToLower() == "age30_35")
                                                {
                                                    ageWhere += " ('" + DateTime.Now.AddYears(-30) + "' >= date_of_birth and '" + DateTime.Now.AddYears(-35) + "' < date_of_birth )or ";
                                                }
                                                if (identityModel.ageList[a_index].ToLower() == "age35_40")
                                                {
                                                    ageWhere += " ('" + DateTime.Now.AddYears(-35) + "' >= date_of_birth and '" + DateTime.Now.AddYears(-40) + "' < date_of_birth )or ";
                                                }
                                                if (identityModel.ageList[a_index].ToLower() == "age40")
                                                {
                                                    ageWhere += " '" + DateTime.Now.AddYears(-40) + "' > date_of_birth or ";
                                                }
                                            }

                                            sqlWhere = sqlWhere + " (" + ageWhere.Substring(0, ageWhere.Length - 3) + ") and";
                                        }

                                        if (!string.IsNullOrWhiteSpace(sqlWhere))
                                        {
                                            sqlWhere = sqlWhere.Substring(0, sqlWhere.Length - 3);
                                        }
                                    }


                                    break;
                                case "search-employeedate":
                                    if (!string.IsNullOrWhiteSpace(entry.Value))
                                    {
                                        string dateWhere = entry.FieldKey.Equals("LF_0013", StringComparison.OrdinalIgnoreCase) ? "join_group_date" : "employee_date";
                                        AdvSearchConditionControl.SearchEmployeeDate entryDate = JsonConvert.DeserializeObject<AdvSearchConditionControl.SearchEmployeeDate>(entry.Value);
                                        if (entryDate.chooseYear != null && entryDate.chooseYear.Count > 0)
                                        {
                                            //LessOneYear 不满1年
                                            //OneToTwoYear 满1-2年
                                            //TwoToThreeYear 满2-3年
                                            //ThreeToFourYear 满3-4年
                                            //FourToFiveYear 满4-5年
                                            //MoreThanFiveYear 超过5年
                                            sqlWhere = "( ";
                                            for (int date_index = 0, date_len = entryDate.chooseYear.Count; date_index < date_len; date_index++)
                                            {
                                                if (entryDate.chooseYear[date_index].ToLower() == "lessoneyear")
                                                {
                                                    sqlWhere += "  " + dateWhere + " > '" + DateTime.Now.AddYears(-1) + "' or ";
                                                }
                                                else if (entryDate.chooseYear[date_index].ToLower() == "onetotwoyear")
                                                {
                                                    sqlWhere += "  ('" + DateTime.Now.AddYears(-1) + "' >= " + dateWhere + " and '" + DateTime.Now.AddYears(-2) + "' < " + dateWhere + ") or ";
                                                }
                                                else if (entryDate.chooseYear[date_index].ToLower() == "twotothreeyear")
                                                {
                                                    sqlWhere += "  ('" + DateTime.Now.AddYears(-2) + "' >= " + dateWhere + " and '" + DateTime.Now.AddYears(-3) + "' < " + dateWhere + ") or ";
                                                }
                                                else if (entryDate.chooseYear[date_index].ToLower() == "threetofouryear")
                                                {
                                                    sqlWhere += "  ('" + DateTime.Now.AddYears(-3) + "' >= " + dateWhere + " and '" + DateTime.Now.AddYears(-4) + "' < " + dateWhere + ") or ";
                                                }
                                                else if (entryDate.chooseYear[date_index].ToLower() == "fourtofiveyear")
                                                {
                                                    sqlWhere += "  ('" + DateTime.Now.AddYears(-4) + "'>= " + dateWhere + " and '" + DateTime.Now.AddYears(-5) + "' < " + dateWhere + ") or ";
                                                }
                                                else if (entryDate.chooseYear[date_index].ToLower() == "morethanfiveyear")
                                                {
                                                    sqlWhere += " '" + DateTime.Now.AddYears(-5) + "' > " + dateWhere + " or ";
                                                }
                                            }
                                            if (!string.IsNullOrWhiteSpace(sqlWhere))
                                            {
                                                sqlWhere = sqlWhere.Substring(0, sqlWhere.Length - 3) + " )";
                                            }

                                        }
                                        else
                                        {
                                            if (!string.IsNullOrWhiteSpace(entryDate.startDate) && !string.IsNullOrWhiteSpace(entryDate.endDate))
                                            {
                                                sqlWhere = " " + dateWhere + " between '" + entryDate.startDate + "' and '" + entryDate.endDate + "'";
                                            }
                                            else if (!string.IsNullOrWhiteSpace(entryDate.startDate))
                                            {
                                                sqlWhere = " " + dateWhere + " >= '" + entryDate.startDate + "'";
                                            }
                                            else if (!string.IsNullOrWhiteSpace(entryDate.endDate))
                                            {
                                                sqlWhere = " " + dateWhere + " <= '" + entryDate.endDate + "'";
                                            }
                                        }
                                    }
                                    break;
                                case "search-orgtree":

                                    List<AdvSearchConditionControl.AdvOrgInfo> searchOrg = JsonConvert.DeserializeObject<List<AdvSearchConditionControl.AdvOrgInfo>>(entry.Value);
                                    if (searchOrg != null && searchOrg.Count > 0)
                                    {
                                        string orgWhere = string.Empty;
                                        foreach (var org in searchOrg)
                                        {
                                            if (org.IsAllChecked == false)
                                            {
                                                if (!string.IsNullOrWhiteSpace(org.OrgRelID))
                                                    orgWhere += "'" + org.OrgRelID + "',";
                                            }
                                            else
                                            {
                                                //找出子节点
                                                //var orgChild = AccessService.GetOrgChild(org.OrgRelID, SiteCode);
                                                //foreach (var ktem in orgChild)
                                                //{
                                                //    if (!string.IsNullOrWhiteSpace(ktem))
                                                //        orgWhere += "'" + ktem + "',";
                                                //}
                                                var orgRel = orgData.SingleOrDefault(p => p.Org_relation_id == org.OrgRelID);
                                                IEnumerable<OrgRelationPO> childList = null;
                                                if (orgRel != null)
                                                {
                                                    if (orgRel != null)
                                                    {
                                                        switch (orgRel.Org_level_id)
                                                        {
                                                            case 1:
                                                                childList = orgData.Where(t => t.Org1_relation_id == org.OrgRelID);
                                                                break;
                                                            case 2:
                                                                childList = orgData.Where(t => t.Org2_relation_id == org.OrgRelID);
                                                                break;
                                                            case 3:
                                                                childList = orgData.Where(t => t.Org3_relation_id == org.OrgRelID);
                                                                break;
                                                            case 4:
                                                                childList = orgData.Where(t => t.Org4_relation_id == org.OrgRelID);
                                                                break;
                                                            case 5:
                                                                childList = orgData.Where(t => t.Org5_relation_id == org.OrgRelID);
                                                                break;
                                                            case 6:
                                                                childList = orgData.Where(t => t.Org6_relation_id == org.OrgRelID);
                                                                break;
                                                            case 7:
                                                                childList = orgData.Where(t => t.Org7_relation_id == org.OrgRelID);
                                                                break;
                                                            case 8:
                                                                childList = orgData.Where(t => t.Org8_relation_id == org.OrgRelID);
                                                                break;
                                                            case 9:
                                                                childList = orgData.Where(t => t.Org9_relation_id == org.OrgRelID);
                                                                break;
                                                            case 10:
                                                                childList = orgData.Where(t => t.Org10_relation_id == org.OrgRelID);
                                                                break;
                                                        }
                                                    }
                                                    if (childList != null && childList.Count() > 0)
                                                    {
                                                        foreach (var child in childList)
                                                            orgWhere += "'" + child.Org_relation_id + "',";

                                                    }
                                                }

                                            }

                                        }
                                        if (!string.IsNullOrWhiteSpace(orgWhere))
                                            sqlWhere = sqlWhere + " org_relation_id in (" + orgWhere.TrimEnd(',') + ") ";
                                    }

                                    break;
                            }

                            if (!string.IsNullOrWhiteSpace(sqlWhere)) conditionWhere += sqlWhere + " and ";
                        }
                    }
                    #endregion

                    #region 组织结构

                    if (advance.OrgList != null && advance.OrgList.Count > 0)
                    {
                        string orgWhere = string.Empty;
                        string sqlWhere = string.Empty;
                        foreach (var org in advance.OrgList)
                        {
                            if (org.IsAllChecked == false)
                            {
                                if (!string.IsNullOrWhiteSpace(org.OrgRelID))
                                    orgWhere += "'" + org.OrgRelID + "',";
                            }
                            else
                            {
                                var orgRel = orgData.SingleOrDefault(p => p.Org_relation_id == org.OrgRelID);
                                IEnumerable<OrgRelationPO> childList = null;
                                if (orgRel != null)
                                {
                                    if (orgRel != null)
                                    {
                                        switch (orgRel.Org_level_id)
                                        {
                                            case 1:
                                                childList = orgData.Where(t => t.Org1_relation_id == org.OrgRelID);
                                                break;
                                            case 2:
                                                childList = orgData.Where(t => t.Org2_relation_id == org.OrgRelID);
                                                break;
                                            case 3:
                                                childList = orgData.Where(t => t.Org3_relation_id == org.OrgRelID);
                                                break;
                                            case 4:
                                                childList = orgData.Where(t => t.Org4_relation_id == org.OrgRelID);
                                                break;
                                            case 5:
                                                childList = orgData.Where(t => t.Org5_relation_id == org.OrgRelID);
                                                break;
                                            case 6:
                                                childList = orgData.Where(t => t.Org6_relation_id == org.OrgRelID);
                                                break;
                                            case 7:
                                                childList = orgData.Where(t => t.Org7_relation_id == org.OrgRelID);
                                                break;
                                            case 8:
                                                childList = orgData.Where(t => t.Org8_relation_id == org.OrgRelID);
                                                break;
                                            case 9:
                                                childList = orgData.Where(t => t.Org9_relation_id == org.OrgRelID);
                                                break;
                                            case 10:
                                                childList = orgData.Where(t => t.Org10_relation_id == org.OrgRelID);
                                                break;
                                        }
                                    }
                                    if (childList != null && childList.Count() > 0)
                                    {
                                        foreach (var child in childList)
                                            orgWhere += "'" + child.Org_relation_id + "',";

                                    }
                                }

                            }

                        }
                        if (!string.IsNullOrWhiteSpace(orgWhere))
                            sqlWhere = sqlWhere + " org_relation_id in (" + orgWhere.TrimEnd(',') + ") ";

                        if (!string.IsNullOrWhiteSpace(sqlWhere)) conditionWhere += sqlWhere + " and ";
                    }
                    #endregion

                    if (!string.IsNullOrWhiteSpace(conditionWhere))
                    {
                        conditionWhere = conditionWhere.Substring(0, conditionWhere.Length - 4);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return conditionWhere;
        }

        public class PartTimeConn
        {
            public string SiteCode { get; set; }
            public ORMHelper.ConnectionInfo ConnSite { get; set; }
        }
        private List<SiteSettingPO> GetCrossCompanyParttimeInfoList(ORMHelper.ConnectionInfo connSaas, List<VApiBuParttimePositionInfoPO> PartTimeSetting, List<PositionRelationPO> PartTimePosList, List<OrgRelationPO> PartTimeOrgList, List<SiteSettingPO> SiteSetting)
        {
            if (PartTimeSetting != null && PartTimeSetting.Count > 0)
            {
                List<PartTimeConn> PartTimeConnList = new List<PartTimeConn>();
                try
                {
                    SiteSetting = ORMHelper.GetList<SiteSettingPO>(connSaas, "");
                    foreach (var item in PartTimeSetting)
                    {
                        var ConnSiteSelect = PartTimeConnList.Find(r => r.SiteCode == item.From_site_code);
                        if (ConnSiteSelect == null)
                        {
                            ConnSiteSelect = new PartTimeConn() { SiteCode = item.From_site_code, ConnSite = OpenConnection(ConnType.Site, item.From_site_code) };
                            PartTimeConnList.Add(ConnSiteSelect);
                        }

                        var PartPos = ORMHelper.Get<PositionRelationPO>(ConnSiteSelect.ConnSite, item.Position_relation_id);
                        if (PartPos == null) continue;

                        PartTimePosList.Add(PartPos);

                        var Partorg = ORMHelper.Get<OrgRelationPO>(ConnSiteSelect.ConnSite, PartPos.Org_relation_id);
                        if (Partorg == null) continue;
                        //PartTimeOrgList.Add(Partorg);
                        if (!string.IsNullOrWhiteSpace(Partorg.Org1_relation_id) && !PartTimeOrgList.Exists(p => p.Org_relation_id == Partorg.Org1_relation_id))
                        {
                            var Partorg1 = ORMHelper.Get<OrgRelationPO>(ConnSiteSelect.ConnSite, Partorg.Org1_relation_id);
                            if (Partorg1 != null) PartTimeOrgList.Add(Partorg1);
                        }
                        if (!string.IsNullOrWhiteSpace(Partorg.Org2_relation_id) && !PartTimeOrgList.Exists(p => p.Org_relation_id == Partorg.Org2_relation_id))
                        {
                            var Partorg2 = ORMHelper.Get<OrgRelationPO>(ConnSiteSelect.ConnSite, Partorg.Org2_relation_id);
                            if (Partorg2 != null) PartTimeOrgList.Add(Partorg2);
                        }

                        if (!string.IsNullOrWhiteSpace(Partorg.Org3_relation_id) && !PartTimeOrgList.Exists(p => p.Org_relation_id == Partorg.Org3_relation_id))
                        {
                            var Partorg3 = ORMHelper.Get<OrgRelationPO>(ConnSiteSelect.ConnSite, Partorg.Org3_relation_id);
                            if (Partorg3 != null) PartTimeOrgList.Add(Partorg3);
                        }

                        if (!string.IsNullOrWhiteSpace(Partorg.Org4_relation_id) && !PartTimeOrgList.Exists(p => p.Org_relation_id == Partorg.Org4_relation_id))
                        {
                            var Partorg4 = ORMHelper.Get<OrgRelationPO>(ConnSiteSelect.ConnSite, Partorg.Org4_relation_id);
                            if (Partorg4 != null) PartTimeOrgList.Add(Partorg4);
                        }

                        if (!string.IsNullOrWhiteSpace(Partorg.Org5_relation_id) && !PartTimeOrgList.Exists(p => p.Org_relation_id == Partorg.Org5_relation_id))
                        {
                            var Partorg5 = ORMHelper.Get<OrgRelationPO>(ConnSiteSelect.ConnSite, Partorg.Org5_relation_id);
                            if (Partorg5 != null) PartTimeOrgList.Add(Partorg5);
                        }

                        if (!string.IsNullOrWhiteSpace(Partorg.Org6_relation_id) && !PartTimeOrgList.Exists(p => p.Org_relation_id == Partorg.Org6_relation_id))
                        {
                            var Partorg6 = ORMHelper.Get<OrgRelationPO>(ConnSiteSelect.ConnSite, Partorg.Org6_relation_id);
                            if (Partorg6 != null) PartTimeOrgList.Add(Partorg6);
                        }

                        if (!string.IsNullOrWhiteSpace(Partorg.Org7_relation_id) && !PartTimeOrgList.Exists(p => p.Org_relation_id == Partorg.Org7_relation_id))
                        {
                            var Partorg7 = ORMHelper.Get<OrgRelationPO>(ConnSiteSelect.ConnSite, Partorg.Org7_relation_id);
                            if (Partorg7 != null) PartTimeOrgList.Add(Partorg7);
                        }
                        if (!string.IsNullOrWhiteSpace(Partorg.Org8_relation_id) && !PartTimeOrgList.Exists(p => p.Org_relation_id == Partorg.Org8_relation_id))
                        {
                            var Partorg8 = ORMHelper.Get<OrgRelationPO>(ConnSiteSelect.ConnSite, Partorg.Org8_relation_id);
                            if (Partorg8 != null) PartTimeOrgList.Add(Partorg8);
                        }

                        if (!string.IsNullOrWhiteSpace(Partorg.Org9_relation_id) && !PartTimeOrgList.Exists(p => p.Org_relation_id == Partorg.Org9_relation_id))
                        {
                            var Partorg9 = ORMHelper.Get<OrgRelationPO>(ConnSiteSelect.ConnSite, Partorg.Org9_relation_id);
                            if (Partorg9 != null) PartTimeOrgList.Add(Partorg9);
                        }

                        if (!string.IsNullOrWhiteSpace(Partorg.Org10_relation_id) && !PartTimeOrgList.Exists(p => p.Org_relation_id == Partorg.Org10_relation_id))
                        {
                            var Partorg10 = ORMHelper.Get<OrgRelationPO>(ConnSiteSelect.ConnSite, Partorg.Org10_relation_id);
                            if (Partorg10 != null) PartTimeOrgList.Add(Partorg10);
                        }
                    }
                    foreach (var item in PartTimeConnList)
                    {
                        if (item.ConnSite != null) item.ConnSite.CloseConn();
                    }

                }
                catch (Exception)
                {
                    foreach (var item in PartTimeConnList)
                    {
                        if (item.ConnSite != null) item.ConnSite.CloseConn();
                    }
                }
            }

            return SiteSetting;
        }

        #region 管理员日志记录
        public void SetAdminManageLog(BaseInfo baseInfo, SetAdminManageLogRequest request)
        {
            ORMHelper.ConnectionInfo connSaas = null;
            try
            {
                this.Logger.Info($"++++++++++ SetAdminManageLog start request => TenantID:{request.TenantID} | Module:{request.Module} | FunctionName:{request.FunctionName} ");
                connSaas = OpenConnection(ConnType.Saas);
                this.Logger.Info($"++++++++++ SetAdminManageLog OpenConnection ");
                //判断操作是否需要记录日志
                if (ORMHelper.GetCount<FunctionDescribePO>(connSaas, $"where module='{ConvertDBValue(request.Module)}' and function_name='{ConvertDBValue(request.FunctionName)}' ") > 0)
                {
                    //记录日志
                    ORMHelper.Insert<string>(connSaas, new AdminManageOperationLogPO()
                    {
                        Key_id = Guid.NewGuid().ToString(),
                        Admin_account = baseInfo.EmpCode,
                        Module = request.Module,
                        Function_name = request.FunctionName,
                        Page_code = request.PageCode,
                        Operate_dt = DateTime.Now
                    });
                }
                this.Logger.Info($"++++++++++ SetAdminManageLog end ");
            }
            catch (Exception ex)
            {
                this.Logger.Error($"++++++++++ SetAdminManageLog 管理员日志记录 发生异常 ==> {JsonConvert.SerializeObject(ex)} | at {DateTime.Now}");
            }
            finally
            {
                connSaas?.CloseConn();
            }
        }

        #endregion

    }
}
