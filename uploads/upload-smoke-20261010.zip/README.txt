TenantLog upload smoke test, no customer data.
